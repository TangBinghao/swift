# Copyright (c) Alibaba, Inc. and its affiliates.

from swift.aigc import infer_controlnet_sdxl

if __name__ == '__main__':
    infer_controlnet_sdxl()
