# Copyright (c) Alibaba, Inc. and its affiliates.

from swift.aigc import infer_dreambooth_lora_sdxl

if __name__ == '__main__':
    infer_dreambooth_lora_sdxl()
