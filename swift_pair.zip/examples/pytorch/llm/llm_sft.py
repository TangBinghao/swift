# Copyright (c) Alibaba, Inc. and its affiliates.
import custom

from swift.llm import sft_main

if __name__ == '__main__':
    output = sft_main()
