pip install -e '.[llm]' -i https://mirrors.tencent.com/tencent_pypi/simple
pip install -i https://mirrors.tencent.com/tencent_pypi/simple timm==1.0.3 deepspeed==0.14.3 Pillow==10.1.0
pip install -i https://mirrors.tencent.com/tencent_pypi/simple  importlib_metadata
pip install -i https://mirrors.tencent.com/tencent_pypi/simple  oss2
pip install -i https://mirrors.tencent.com/tencent_pypi/simple  addict
pip install -i https://mirrors.tencent.com/tencent_pypi/simple  datasets==2.18.0