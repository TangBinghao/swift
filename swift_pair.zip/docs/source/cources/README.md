The courses of this folder are transfered to [the classroom repo](https://github.com/modelscope/modelscope-classroom).
