# Copyright (c) Alibaba, Inc. and its affiliates.

from swift.aigc import animatediff_main

if __name__ == '__main__':
    animatediff_main()
