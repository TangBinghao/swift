# Copyright (c) Alibaba, Inc. and its affiliates.
from swift.aigc import infer_text_to_image_sdxl

if __name__ == '__main__':
    infer_text_to_image_sdxl()
