# Copyright (c) Alibaba, Inc. and its affiliates.

from swift.aigc import infer_dreambooth

if __name__ == '__main__':
    infer_dreambooth()
