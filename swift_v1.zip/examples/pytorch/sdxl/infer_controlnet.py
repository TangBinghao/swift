# Copyright (c) Alibaba, Inc. and its affiliates.

from swift.aigc import infer_controlnet

if __name__ == '__main__':
    infer_controlnet()
