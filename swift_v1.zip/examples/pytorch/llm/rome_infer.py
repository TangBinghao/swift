# Copyright (c) Alibaba, Inc. and its affiliates.

from swift.llm import rome_main

if __name__ == '__main__':
    rome_main()
