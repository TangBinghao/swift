# Copyright (c) Alibaba, Inc. and its affiliates.
import custom

from swift.llm import infer_main

if __name__ == '__main__':
    result = infer_main()
